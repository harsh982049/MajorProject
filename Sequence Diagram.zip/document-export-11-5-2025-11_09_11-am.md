# Major Project Sequence Diagram



